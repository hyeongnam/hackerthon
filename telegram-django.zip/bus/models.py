from django.db import models


class BusGo(models.Model):
    chat_id = models.CharField(max_length=20)
    go_station_id = models.CharField(max_length=20)
    go_route_id = models.CharField(max_length=20)
    go_station_order = models.CharField(max_length=5)


class BusOut(models.Model):
    chat_id = models.CharField(max_length=20)
    out_station_id = models.CharField(max_length=20)
    out_route_id = models.CharField(max_length=20)
    out_station_order = models.CharField(max_length=5)
